﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Four : System.Web.UI.Page
{
    //SqlConnection SQLConn = new SqlConnection("Data Source=203.68.62.33;Initial Catalog=DB_OPD;Persist Security Info=True;User ID=qid;Password=qid");
    //SqlConnection SQLConn = new SqlConnection(@"Data Source=DESKTOP-2FVJI93\SQLEXPRESS;Initial Catalog=DB_EXE1;Persist Security Info=True;User ID=Exc1;Password=Exc1");
    //SqlConnection SQLConn = new SqlConnection(@"Data Source=203.68.62.33;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");
    //SqlConnection SQLConn = new SqlConnection(@"Data Source=localhost;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");
    SqlConnection SQLConn = new SqlConnection(@"Data Source=203.64.37.95;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["gsUserID"] == null || Session["gsUserID"] =="")
        {
            showMsg(Page, "請重新登入", "First.aspx");
            return;
        }

        //判斷網頁是否第一次載入
        if (IsPostBack == false)
        {
            string mDate = "";
            mDate = Request.QueryString["Date"];

            if (mDate == "")
            {
                showMsg(Page, "傳遞的參數有誤", "First.aspx");
                return;
            }
            AES.AES mAES = new AES.AES();
            string mDate2 = "";
            mDate2 = mAES.AESdecrypt(mDate, "Tzuchi@AppLogin");

            //日期長度有誤請重新輸入
            if (mDate2.ToString().Length != 7)
            {
                showMsg(Page, "日期長度有誤請重新輸入", "Four.aspx");
                return;
            }

            lblDate.Text = mDate2;

            //定義SQL字串
            string strSQL = "";
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            //登入Problem
            strSQL = " select  chSeeDate,chPNC,chRoom,intRegNo,left(chMRNo,3)+'****'+ substring(chMRNo,8,3) as 病歷號碼, " + 
                     "left(chPatName,1)+'*'+ substring(chPatName,3,1) as 姓名,chBirthDay,chDrNo,chIcd9No1,chIcd9No2,chIcd9No3 " +
                     "from OpdQuoteBase1Tbl ";
            strSQL += " where chSeeDate = '" + mDate2 + "'";
            ds = SQLQry(strSQL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
            }


        }

    }

    //LoginInjection Qry使用
    public DataSet SQLQry(string strSQL)
    {
        DataSet ds = new DataSet();
        SqlDataAdapter ad = new SqlDataAdapter();
        SQLConn.Close();
        SQLConn.Open();
        ad = new SqlDataAdapter(strSQL, SQLConn);
        ad.Fill(ds);
        SQLConn.Close();
        return ds;
    }

    //MSG
    public static void showMsg(System.Web.UI.Page Page, String Message, String Redirect)
    {
        String JS;
        JS = "<script language='JavaScript'>";
        JS += "window.alert('";
        JS += Message + "');";
        if (Redirect == "")
        {

        }
        else
        {
            JS += "document.location='" + Redirect + "';";

        }
        JS += "</SCRIPT>";

        Page.ClientScript.RegisterStartupScript(Page.GetType(), "", JS);
        return;
    }

}