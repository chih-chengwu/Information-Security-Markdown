﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Second : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtOP.Text = Session["gsUserID"].ToString().Trim(); 
    }
    protected void butReturn_Click(object sender, EventArgs e)
    {
        //重新導向index.aspx
        Response.Redirect("First.aspx");
    }
    protected void butQry_Click(object sender, EventArgs e)
    {
        if (txtQryDate.Text.ToString().Trim().Length != 7)
        {
            showMsg(Page, "日期格式錯誤", "");
            return;
        }

        string AllowSmallDate = Date7(DateTime.Now.AddDays(-30));


        if (Convert.ToInt32(txtQryDate.Text.Trim()) < Convert.ToInt32(AllowSmallDate))
        {
            showMsg(Page, "只可查詢ㄧ個月內的資料", "");
            return;
        }

        //AES.AES mAES = new AES.AES();
        //string mParaStr = "";
        //mParaStr = mAES.AESencrypt(txtSDate.Text, "Tzuchi@AppLogin");
        Response.Redirect("Third.aspx?Date=" + Server.UrlEncode(txtQryDate.Text.Trim()));
    }
    public string Date7(DateTime dateNow)
    {
        string month, day;
        string dateRe;
        if (dateNow.Month.ToString().Length == 1)
        {
            month = "0" + dateNow.Month.ToString();
        }
        else
        {
            month = dateNow.Month.ToString();
        }

        if (dateNow.Day.ToString().Length == 1)
        {
            day = "0" + dateNow.Day.ToString();
        }
        else
        {
            day = dateNow.Day.ToString();
        }

        dateRe = (Convert.ToInt16(dateNow.Year) - 1911) + month + day;

        return dateRe;
    }
    //MSG
    public static void showMsg(System.Web.UI.Page Page, String Message, String Redirect)
    {
        String JS;
        JS = "<script language='JavaScript'>";
        JS += "window.alert('";
        JS += Message + "');";
        if (Redirect == "")
        {

        }
        else
        {
            JS += "document.location='" + Redirect + "';";

        }
        JS += "</SCRIPT>";

        Page.ClientScript.RegisterStartupScript(Page.GetType(), "", JS);
        return;
    }

    protected void butAES_Click(object sender, EventArgs e)
    {
        if (txtQryDate.Text.ToString().Trim().Length != 7)
        {
            showMsg(Page, "日期格式錯誤", "");
            return;
        }

        string AllowSmallDate = Date7(DateTime.Now.AddDays(-30));


        if (Convert.ToInt32(txtQryDate.Text.Trim()) < Convert.ToInt32(AllowSmallDate))
        {
            showMsg(Page, "只可查詢ㄧ個月內的資料", "");
            return;
        }

        AES.AES mAES = new AES.AES();
        string mParaStr = "";
        mParaStr = mAES.AESencrypt(txtQryDate.Text.Trim() , "Tzuchi@AppLogin");
        Response.Redirect("Four.aspx?Date=" + Server.UrlEncode(mParaStr));
    }
}