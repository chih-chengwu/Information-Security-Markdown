﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public partial class _Default : System.Web.UI.Page
{
    //SqlConnection SQLConn = new SqlConnection(@"Data Source=203.68.62.33;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");
    //SqlConnection SQLConn = new SqlConnection(@"Data Source=localhost;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");
    SqlConnection SQLConn = new SqlConnection(@"Data Source=203.64.37.95;Initial Catalog=DB_TEST;Persist Security Info=True;User ID=Exc;Password=Excpwd");

    protected void Page_Load(object sender, EventArgs e)
    {
        //showMsg(Page, "hhhhhhhhh:" + IsPostBack, "");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        txtUserID.Text = txtUserID.Text.ToUpper();
    }
    protected void butInjection_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        //DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        //登入Problem
        strSQL = "select * from dbo.EmployeeTbl ";
        strSQL += " where chUserID = '" + txtUserID.Text.Trim () + "'";
        strSQL += " and chPassWord = '" + txtPassword.Text.Trim () + "'";
        ds = SQLQry(strSQL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

            //登入成功，重新導向index.aspx
            Response.Redirect("Second.aspx");
        }
        else
        {
            showMsg(Page, "帳號密碼錯誤", "");
        }
    }
    //LoginInjection Qry使用
    public DataSet SQLQry(string strSQL)
    {
        DataSet ds = new DataSet();
        SqlDataAdapter ad = new SqlDataAdapter();
        SQLConn.Close();
        SQLConn.Open();
        ad = new SqlDataAdapter(strSQL, SQLConn);
        ad.Fill(ds);
        SQLConn.Close();
        return ds;
    }

    public DataTable SQLQryDt(string strSQL)
    {
        DataTable dt = new DataTable();
        SqlDataAdapter ad = new SqlDataAdapter();
        SQLConn.Close();
        SQLConn.Open();
        ad = new SqlDataAdapter(strSQL, SQLConn);
        ad.Fill(dt);
        SQLConn.Close();
        return dt;
    }

    protected void butSafe_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        SqlCommand SQLCmd = new SqlCommand();
        SqlParameter mPara = new SqlParameter();
        DataSet ds = new DataSet();
        //DataTable dt = new DataTable();

        //登入OK
        strSQL = "select * from dbo.EmployeeTbl ";
        strSQL += " where chUserID = '" + txtUserID.Text.Trim() + "'";

        ds = SQLQry(strSQL);

        //只能有一筆, 其他都是錯誤的
        if (ds.Tables[0].Rows.Count == 1)
        {
            //找到該筆ID資料庫的資料row後, 比對螢幕上的密碼是否相等
            if (ds.Tables[0].Rows[0]["chPassWord"].ToString().Trim() == txtPassword.Text.Trim()  )
            {

                Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

                //登入成功，重新導向index.aspx
                Response.Redirect("Second.aspx");
            }
            else
            {
                showMsg(Page, "帳號密碼錯誤", "");
            }

        }
        else
        {
            showMsg(Page, "帳號密碼錯誤", "");
        }
    }

    //Login Qry使用
    public DataSet SQLQryOK(SqlCommand SQLCmd)
    {
        DataSet ds = new DataSet();
        SqlDataAdapter ad = new SqlDataAdapter();
        SQLConn.Close();
        SQLConn.Open();
        ad.SelectCommand = SQLCmd;
        ad.Fill(ds);
        SQLConn.Close();
        return ds;
    }
    protected void butEnd_Click(object sender, EventArgs e)
    {

    }
 

    //MSG
    public static void showMsg(System.Web.UI.Page Page, String Message, String Redirect)
    {
        String JS;
        JS = "<script language='JavaScript'>";
        JS += "window.alert('";
        JS += Message + "');";
        if (Redirect == "")
        {

        }
        else
        {
            JS += "document.location='" + Redirect + "';";

        }
        JS += "</SCRIPT>";

        Page.ClientScript.RegisterStartupScript(Page.GetType(), "", JS);
        return;
    }



    protected void butTwoPara_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();

        //登入OK
        strSQL = "SELECT * FROM dbo.EmployeeTbl WHERE chUserID=@UserID ";
        //strSQL = "SELECT * FROM dbo.EmployeeTbl WHERE chUserID=@UserID  and chPassWord=@Password"; 
        SqlCommand SQLCmd = new SqlCommand(strSQL, SQLConn);

        SQLCmd.Parameters.Add("@UserID", SqlDbType.Char).Value = txtUserID.Text.Trim();
        //SQLCmd.Parameters.Add("@Password", SqlDbType.Char).Value = txtPassword.Text.Trim();

        ds = SQLQryOK(SQLCmd);

        if (ds.Tables[0].Rows.Count == 1)
        {
            //只有驗證成功才算可登入，其他都回傳0，表室登入失敗
            if (ds.Tables[0].Rows[0]["chPassWord"].ToString().Trim() == txtPassword.Text.Trim())
            {

                Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

                //登入成功，重新導向index.aspx
                Response.Redirect("Second.aspx");
            }
            else
            {
                showMsg(Page, "帳號密碼錯誤", "");
            }

        }
        else
        {
            showMsg(Page, "帳號密碼錯誤", "");
        }
    }


 
    protected void butMD5_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        SqlCommand SQLCmd = new SqlCommand();
        SqlParameter mPara = new SqlParameter();
        DataSet ds = new DataSet();
        //DataTable dt = new DataTable();

        //登入OK
        strSQL = "select * from dbo.EmployeeTbl ";
        strSQL += " where chUserID = '" + txtUserID.Text.Trim() + "'";

        ds = SQLQry(strSQL);

        //只能有一筆, 其他都是錯誤的
        if (ds.Tables[0].Rows.Count == 1)
        {
            //找到該筆ID資料庫的資料row後, 比對螢幕上的密碼是否相等
            if (ds.Tables[0].Rows[0]["chPwdMD5"].ToString().Trim() == inpHash.Value)
            {

                Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

                //登入成功，重新導向index.aspx
                Response.Redirect("Second.aspx");
            }
            else
            {
                showMsg(Page, "帳號密碼錯誤", "");
            }

        }
        else
        {
            showMsg(Page, "帳號密碼錯誤", "");
        }
    }

    protected void butOTP_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        SqlCommand SQLCmd = new SqlCommand();
        SqlParameter mPara = new SqlParameter();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();

        //登入OK
        strSQL = "select * from dbo.EmployeeTbl ";
        strSQL += " where chUserID = '" + txtUserID.Text.Trim() + "'";

        ds = SQLQry(strSQL);

        //只能有一筆, 其他都是錯誤的
        if (ds.Tables[0].Rows.Count != 1) 
        {
            showMsg(Page, "帳號密碼錯誤", "");
            return;
        } 
        
            strSQL = "exec sp_AskLogin_1 '" + txtUserID.Text.Trim() + "'";
            dt = SQLQryDt(strSQL);
        
            //找到該筆ID資料庫的資料row後, 比對螢幕上的密碼是否相等
            if (dt.Rows[0]["Status"].ToString().Trim() != "0")
            {
                showMsg(Page, "帳號密碼錯誤", "");
                return;
            }
        strSQL = "declare @mstr char(32)";
        strSQL += " select @mstr = upper(right(master.sys.fn_varbintohexstr(HASHBYTES('MD5',rtrim('" + dt.Rows[0]["RandStr"].ToString().Trim() + "'+ '" + inpHash.Value.ToString().Trim() + "'))),32)) ";
        strSQL += " exec sp_Response_2 '" + txtUserID.Text.ToString().Trim() + "','";
        strSQL += dt.Rows[0]["DateTime"].ToString().Trim() + "',";
        strSQL += "@mstr";

        txtPassword.Text = dt.Rows[0]["RandStr"].ToString().Trim() + inpHash.Value.ToString().Trim();
        txtUserID.Text = txtUserID.Text.ToString().Trim();
   
            dt = SQLQryDt(strSQL);
            if (dt.Rows[0]["Status"].ToString().Trim() != "0")
            {
                showMsg(Page, "帳號密碼錯誤", "");
                return;
            }

                Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

                //登入成功，重新導向index.aspx
                Response.Redirect("Second.aspx");
                    

        
     
    }



    protected void butMD5_2_Click(object sender, EventArgs e)
    {
        //定義SQL字串
        string strSQL = "";
        SqlCommand SQLCmd = new SqlCommand();
        SqlParameter mPara = new SqlParameter();
        DataSet ds = new DataSet();
        //DataTable dt = new DataTable();

        //登入OK
        strSQL = "select * from dbo.EmployeeTbl ";
        strSQL += " where chUserID = '" + txtUserID.Text.Trim() + "'";

        ds = SQLQry(strSQL);

        //只能有一筆, 其他都是錯誤的
        if (ds.Tables[0].Rows.Count == 1)
        {
            MD5 md5Hash = MD5.Create();
            string hash = GetMd5Hash(md5Hash, txtPassword.Text.Trim());
            hash = hash.ToUpper();

            //找到該筆ID資料庫的資料row後, 比對螢幕上的密碼是否相等
            //if (ds.Tables[0].Rows[0]["chPwdMD5"].ToString().Trim() == inpHash.Value)
            if (ds.Tables[0].Rows[0]["chPwdMD5"].ToString().Trim() == hash)
            {

                Session["gsUserID"] = ds.Tables[0].Rows[0]["chUserID"].ToString().Trim();

                //登入成功，重新導向index.aspx
                Response.Redirect("Second.aspx");
            }
            else
            {
                showMsg(Page, "帳號密碼錯誤", "");
            }

        }
        else
        {
            showMsg(Page, "帳號密碼錯誤", "");
        }
    }

    static string GetMd5Hash(MD5 md5Hash, string input)
    {

        // Convert the input string to a byte array and compute the hash.
        byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

        // Create a new Stringbuilder to collect the bytes
        // and create a string.
        StringBuilder sBuilder = new StringBuilder();

        // Loop through each byte of the hashed data 
        // and format each one as a hexadecimal string.
        for (int i = 0; i < data.Length; i++)
        {
            sBuilder.Append(data[i].ToString("x2"));
        }

        // Return the hexadecimal string.
        return sBuilder.ToString();
    }



}